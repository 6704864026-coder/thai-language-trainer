import java.util.ArrayList;
import java.util.List;

public class LearnThai {
    
    public static void main(String[] args) {
        List<ThaiConsonant> easyConsonantsList = new ArrayList<>();
        System.out.println("---Easy Quiz---");

        easyConsonantsList.add(new ThaiConsonant("ก", "กอ ไก่ (gor gai)", "g", "Mid" ));
        easyConsonantsList.add(new ThaiConsonant("ข", "ขอ ไข่ (kor kai)", "k", "High"));
        easyConsonantsList.add(new ThaiConsonant("ค", "คอ ควาย (kor kwaai)", "k", "Low"));
  
        for (ThaiConsonant Flashcard : easyConsonantsList) {
            System.out.println(Flashcard.isLearned());
        } 

    }


}
