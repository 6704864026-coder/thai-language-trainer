public class FlashcardManager {
     public static void main(String[] args) {
        
        System.out.println("Showing the first flashcard (Where am I?). Click the window to flip it.");
        Flashcard card1 = new Flashcard("Where am I?", "At Global Academy");
        card1.showCard();

        System.out.println("\n(Close the first card window to see the next one...)");

        javax.swing.SwingUtilities.invokeLater(() -> {
            System.out.println("Showing the second flashcard (Thai Consonant). Click to flip.");
            ThaiConsonant thaiCard = new ThaiConsonant(
                "ก",
                "กอ ไก่",
                "gor gai",
                "Mid"
            );
            thaiCard.showCard();
});
     }
}
